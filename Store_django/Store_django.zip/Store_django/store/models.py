from django.db import models


# Create your models here.
class UserInfo(models.Model):
    username = models.CharField(max_length=32)
    password = models.CharField(max_length=128)
    age = models.IntegerField(verbose_name="年龄", null=True)
    gender_choices = (
        (1, "man"),
        (2, "woman"),
    )
    gender = models.SmallIntegerField(verbose_name="性别", choices=gender_choices, null=True)
    account = models.DecimalField(verbose_name="账号余额", max_digits=10, decimal_places=2, default=0, null=True)
    create_time = models.DateField(verbose_name="创建时间", null=True)

    def __str__(self):
        return self.username, self.password


class Title(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    path = models.CharField(max_length=255)


class Img(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    src = models.URLField()


class Product(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    src = models.URLField()
    content = models.TextField()
    description = models.JSONField()


class Aount(models.Model):
    id = models.AutoField(primary_key=True)
    aomunt = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    content = models.TextField()


class Video(models.Model):
    id = models.AutoField(primary_key=True)
    src = models.URLField()


class OthersProduct(models.Model):
    id = models.AutoField(primary_key=True)
    src1 = models.URLField()
    src2 = models.URLField()
    content = models.TextField()


class Information(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255, null=True)
    src = models.URLField(null=True, max_length=255)
    content = models.TextField(null=True)


class Accessories(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255, null=True)
    src1 = models.URLField(null=True, max_length=255)
    src2 = models.URLField(null=True, max_length=255)
    src3 = models.URLField(null=True, max_length=255)
    src4 = models.URLField(null=True, max_length=255)
    src5 = models.URLField(null=True, max_length=255)
    src6 = models.URLField(null=True, max_length=255)
    content = models.JSONField(null=True, max_length=255)


class ProductPrice(models.Model):
    id = models.AutoField(primary_key=True)
    src = models.URLField(max_length=255)
    title = models.CharField(max_length=255)
    currency = models.CharField(max_length=255)
    price = models.IntegerField(max_length=255)


