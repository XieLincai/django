from django.contrib import admin
from .models import UserInfo, Title, Img, Product, Aount, Information, Video, Accessories


@admin.register(UserInfo)
class UserInfoAdmin(admin.ModelAdmin):
    list_display = ('id', 'username', 'password', 'age', 'gender', 'account', 'create_time')
    # 搜索框，通过name字段
    search_fields = ['username']
    # 排序
    ordering = ['id']


@admin.register(Title)
class TitleAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'path')
    # 搜索框，通过name字段
    search_fields = ['title']
    # 排序
    ordering = ['id']


@admin.register(Img)
class ImgAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'src')
    # 搜索框，通过name字段
    search_fields = ['title']
    # 排序
    ordering = ['id']


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'src', 'content')
    list_display_links = ('id', 'title')  # 可以点击的字段链接到详细信息页
    # 搜索框，通过name字段
    search_fields = ['title']
    # 排序
    ordering = ['id']


@admin.register(Aount)
class AountAdmin(admin.ModelAdmin):
    list_display = ('id', 'aomunt', 'type', 'title', 'content')
    list_display_links = ('id', 'type')  # 可以点击的字段链接到详细信息页
    # 搜索框，通过name字段
    search_fields = ['title']
    # 排序
    ordering = ['id']


@admin.register(Information)
class InformationAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'src', 'content')
    list_display_links = ('id', 'title')  # 可以点击的字段链接到详细信息页
    # 搜索框，通过name字段
    search_fields = ['title']
    # 排序
    ordering = ['id']


@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ('id', 'src')
    list_display_links = ('id', 'src')  # 可以点击的字段链接到详细信息页
    # 搜索框，通过name字段
    search_fields = ['src']
    # 排序
    ordering = ['id']


@admin.register(Accessories)
class AccessoriesAdmin(admin.ModelAdmin):
    list_display = ('id', 'content', 'src1', 'src2', 'src3', 'src4', 'src5', 'src6',)
    list_display_links = ('id', 'content')  # 可以点击的字段链接到详细信息页
    # 搜索框，通过name字段
    search_fields = ['content']
    # 排序
    ordering = ['id']
