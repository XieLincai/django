import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import UserInfoSerializer, TitleSerializer, ImgSerializer,\
    ProductSerializer, OthersProductSerializer, AountSerializer, InformationSerializer, VideoSerializer, AccessoriesSerializer, ProductPriceSerializer
from .models import UserInfo, Title, Img, Product, OthersProduct, Aount, Information, Video, Accessories, ProductPrice
from django.contrib.auth.hashers import make_password, check_password


logger = logging.getLogger('django')


@csrf_exempt
@api_view(['POST'])
def user_login(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')
        try:
            user = UserInfo.objects.get(username=username)
            if user and check_password(password, user.password):
                serializer = UserInfoSerializer(user)
                logger.info('successful login')
                return Response({'message': 'successful login', "userinfo": serializer.data})
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '账号或密码错误!'})

    return JsonResponse({'message': '账号或密码错误!'}, status=505)


@csrf_exempt
@api_view(['POST'])
def user_register(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')
        try:
            if data:
                hashed_password = make_password(password)
                user = UserInfo.objects.create(username=username, password=hashed_password)
                logger.info('User register Successful')
                return Response({'message': 'User register Successful ', "userinfo": user.id})
        except Exception as e:
            # 未找到对应的数据
            return JsonResponse({'message': e})
    return JsonResponse({'message': '请求错误!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_title(request):
    if request.method == "GET":
        try:
            title = Title.objects.all()
            if title:
                serializer = TitleSerializer(instance=title, many=True)
                logger.info('acquire title success')
                return Response({'message': 'acquire title success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)

    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_img(request):
    if request.method == "GET":
        try:
            img = Img.objects.all()
            if img:
                serializer = ImgSerializer(instance=img, many=True)
                logger.info('acquire img success')
                return Response({'message': 'acquire img success', "title": serializer.data})
            return print({'message': 'data error'})
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)

    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_amount(request):
    if request.method == "GET":
        try:
            amount = Aount.objects.all()
            if amount:
                serializer = AountSerializer(instance=amount, many=True)
                logger.info('acquire Aount success')
                return Response({'message': 'acquire Aount success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_product(request):
    if request.method == "GET":
        try:
            product = Product.objects.all()
            if product:
                serializer = ProductSerializer(instance=product, many=True)
                logger.info('acquire product success')
                return Response({'message': 'acquire product success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_video(request):
    if request.method == "GET":
        try:
            video = Video.objects.all()
            if video:
                serializer = VideoSerializer(instance=video, many=True)
                logger.info('acquire video success')
                return Response({'message': 'acquire video success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_othersProduct(request):
    if request.method == "GET":
        try:
            othersProduct = OthersProduct.objects.all()
            if othersProduct:
                serializer = OthersProductSerializer(instance=othersProduct, many=True)
                logger.info('acquire othersProduct success')
                return Response({'message': 'acquire othersProduct success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_information(request):
    if request.method == "GET":
        try:
            information = Information.objects.all()
            if information:
                serializer = InformationSerializer(instance=information, many=True)
                logger.info('acquire information success')
                return Response({'message': 'acquire information success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_accessories(request):
    if request.method == "GET":
        try:
            information = Accessories.objects.all()
            if information:
                serializer = AccessoriesSerializer(instance=information, many=True)
                logger.info('acquire information success')
                return Response({'message': 'acquire information success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


@csrf_exempt
@api_view(['GET'])
def get_productPrice(request):
    if request.method == "GET":
        try:
            productPrice = ProductPrice.objects.all()
            if productPrice:
                serializer = ProductPriceSerializer(instance=productPrice, many=True)
                logger.info('acquire productPrice success')
                return Response({'message': 'acquire information success', "title": serializer.data})
            return print('数据错误')
        except Exception as e:
            # 未找到对应的数据
            print('error:',e)
            return JsonResponse({'message': '请求错误，未找到数据!'},status=202)
    return JsonResponse({'message': '请求错误，未找到数据!!'}, status=505)


