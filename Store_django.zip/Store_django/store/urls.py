from django.urls import path
from store import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('login/', views.user_login, name='user_login'),
    path('register/', views.user_register, name='user_register'),


    path('getTitle/', views.get_title, name='get_title'),
    path('getImg/', views.get_img, name='get_img'),
    path('getAount/', views.get_amount, name='get_amount'),
    path('getProduct/', views.get_product, name='get_product'),
    path('getVideo/', views.get_video, name='get_video'),
    path('getOthersProduct/', views.get_othersProduct, name='get_othersProduct'),
    path('getInformation/', views.get_information, name='get_information'),
    path('getAccessories/', views.get_accessories, name='get_accessories'),
    path('getProductPrice/', views.get_productPrice, name='get_productPrice'),
]